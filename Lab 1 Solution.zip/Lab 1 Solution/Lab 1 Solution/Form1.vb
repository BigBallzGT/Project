﻿Public Class Form1
    ' Phil DeLashmutt
    ' Visual Basic II
    ' 1/31/2014

    Dim win As Integer
    Dim loss As Integer
    Dim tie As Integer
    Dim dierandom As New Random
    Dim result As Integer
    Dim p1 As Integer
    Dim p2 As Integer
    Dim c1 As Integer
    Dim c2 As Integer

    Private Sub Newgame()
        win = 0
        loss = 0
        tie = 0
        PlayerDie1.Image = ImageList1.Images(0)
        PlayerDie2.Image = ImageList1.Images(0)
        ComputerDie1.Image = ImageList1.Images(0)
        ComputerDie2.Image = ImageList1.Images(0)
        lblResult.Text = ""
        lblwin1.Text = ""
        lblWin2.Text = ""
        picC1.Visible = False
        PicC2.Visible = False
        picP1.Visible = False
        picP2.Visible = False


        Call Counter(win, loss, tie)
    End Sub

    Private Sub Results(ByVal p1 As Integer, ByVal p2 As Integer, ByVal c1 As Integer, ByVal c2 As Integer)
        Dim spot1 As Integer
        Dim spot2 As Integer
        If p1 <> c1 Then
            If p1 > c1 Then
                spot1 = 1
                lblwin1.Text = "Winner"
                picP1.Visible = True
                picC1.Visible = False
            ElseIf p1 < c1 Then
                spot1 = 2
                lblwin1.Text = "Winner"
                picP1.Visible = False
                picC1.Visible = True
            End If
        Else
            spot1 = 0
            lblwin1.Text = "Tie"
            picP1.Visible = True
            picC1.Visible = True
        End If
        If p2 <> c2 Then
            If p2 > c2 Then
                spot2 = 1
                lblWin2.Text = "Winner"
                picP2.Visible = True
                PicC2.Visible = False
            Else
                spot2 = 2
                lblWin2.Text = "Winner"
                picP2.Visible = False
                PicC2.Visible = True
            End If
        Else
            spot2 = 0
            lblWin2.Text = "Tie"
            picP2.Visible = True
            PicC2.Visible = True
        End If
        If spot1 = 1 Then
            If spot2 = 0 Then
                win = win + 1
                lblResult.Text = "You Win!"
            ElseIf spot2 = 1 Then
                win = win + 1
                lblResult.Text = "You Win!"
            ElseIf spot2 = 2 Then
                tie = tie + 1
                lblResult.Text = "Tie!"
            End If
        End If
        If spot1 = 2 Then
            If spot2 = 1 Then
                tie = tie + 1
                lblResult.Text = "Tie!"
            Else
                loss = loss + 1
                lblResult.Text = "You Lost!"
            End If
        End If
        If spot1 = 0 Then
            lblwin1.Text = "Tie"
            If spot2 = 1 Then
                win = win + 1
                lblResult.Text = "You Win!"
            ElseIf spot2 = 2 Then
                loss = loss + 1
                lblResult.Text = "You Lost!"
            ElseIf spot2 = 0 Then
                tie = tie + 1
                lblResult.Text = "Tie!"
            End If
        End If
        Call Counter(win, loss, tie)
    End Sub

    Private Sub Counter(ByRef cwin As Integer, ByRef closs As Integer, ByRef ctie As Integer)
        lblGame.Text = cwin & "-" & closs & "-" & ctie

    End Sub

    Private Sub DieRoll(ByVal who As Integer, ByVal which As Integer)
        result = dierandom.Next(1, 7)
        If who = 1 Then
            If which = 1 Then
                PlayerDie1.Image = ImageList1.Images(result)
                p1 = result
            Else
                PlayerDie2.Image = ImageList1.Images(result)
                p2 = result
            End If
        Else
            If which = 1 Then
                ComputerDie1.Image = ImageList1.Images(result)
                c1 = result
            Else
                ComputerDie2.Image = ImageList1.Images(result)
                c2 = result
            End If
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim dlgresult As DialogResult
        dlgresult = MessageBox.Show("Do you really want to quit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If dlgresult = Windows.Forms.DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        ImageList1.Images.Add(System.Drawing.Image.FromFile("diex.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die1.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die2.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die3.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die4.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die5.png"))
        ImageList1.Images.Add(System.Drawing.Image.FromFile("die6.png"))
        ImageList2.Images.Add(System.Drawing.Image.FromFile("Next.gif"))
        ImageList2.Images.Add(System.Drawing.Image.FromFile("prev.gif"))

        picC1.Image = ImageList2.Images(0)
        PicC2.Image = ImageList2.Images(0)
        picP1.Image = ImageList2.Images(1)
        picP2.Image = ImageList2.Images(1)

        PlayerDie1.Image = ImageList1.Images(0)
        PlayerDie2.Image = ImageList1.Images(0)
        ComputerDie1.Image = ImageList1.Images(0)
        ComputerDie2.Image = ImageList1.Images(0)

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Dim newgme As DialogResult
        newgme = MessageBox.Show("Would you like to start a new game?", "New Game?", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If newgme = Windows.Forms.DialogResult.Yes Then
            win = 0
            loss = 0
            tie = 0
            Call Counter(win, loss, tie)
            Call Newgame()
        End If
    End Sub

    Private Sub btnRoll_Click(sender As Object, e As EventArgs) Handles btnRoll.Click
        If win = 5 Then
            MessageBox.Show("You won!  Please press New Game to start again!", "You Won!", MessageBoxButtons.OK)
            Exit Sub
        End If
        If loss = 5 Then
            MessageBox.Show("You lost!  Please press New Game to start again!", "You Lost!", MessageBoxButtons.OK)
            Exit Sub

        End If
        Call DieRoll(1, 1)
        Call DieRoll(1, 2)
        Call DieRoll(2, 1)
        Call DieRoll(2, 2)
        Call Results(p1, p2, c1, c2)

        If win = 5 Then
            MessageBox.Show("You won!  Please press New Game to start again!", "You Won!", MessageBoxButtons.OK)
            Exit Sub
        End If
        If loss = 5 Then
            MessageBox.Show("You lost!  Please press New Game to start again!", "You Lost!", MessageBoxButtons.OK)
            Exit Sub
        End If

    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show("Space Dice is a simple game.  The program will do all the work for you.  The player and the computer both roll 2 die.  The dice are then compared to eachother, top to top, bottom to bottom.  The winner of that round is then determined.  First to 5 wins!", "About")
    End Sub
End Class
