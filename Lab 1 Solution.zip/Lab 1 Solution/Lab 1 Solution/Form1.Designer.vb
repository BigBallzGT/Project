﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.PlayerDie1 = New System.Windows.Forms.PictureBox()
        Me.PlayerDie2 = New System.Windows.Forms.PictureBox()
        Me.ComputerDie1 = New System.Windows.Forms.PictureBox()
        Me.ComputerDie2 = New System.Windows.Forms.PictureBox()
        Me.lblYou = New System.Windows.Forms.Label()
        Me.lblThem = New System.Windows.Forms.Label()
        Me.lblVs = New System.Windows.Forms.Label()
        Me.lblCurrent = New System.Windows.Forms.Label()
        Me.lblGame = New System.Windows.Forms.Label()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnRoll = New System.Windows.Forms.Button()
        Me.lblwin1 = New System.Windows.Forms.Label()
        Me.lblWin2 = New System.Windows.Forms.Label()
        Me.picP1 = New System.Windows.Forms.PictureBox()
        Me.picC1 = New System.Windows.Forms.PictureBox()
        Me.picP2 = New System.Windows.Forms.PictureBox()
        Me.PicC2 = New System.Windows.Forms.PictureBox()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.ImageList2 = New System.Windows.Forms.ImageList(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.PlayerDie1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PlayerDie2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComputerDie1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComputerDie2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picP1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picC1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picP2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicC2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(53, 53)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'PlayerDie1
        '
        Me.PlayerDie1.Location = New System.Drawing.Point(71, 52)
        Me.PlayerDie1.Name = "PlayerDie1"
        Me.PlayerDie1.Size = New System.Drawing.Size(53, 53)
        Me.PlayerDie1.TabIndex = 0
        Me.PlayerDie1.TabStop = False
        '
        'PlayerDie2
        '
        Me.PlayerDie2.Location = New System.Drawing.Point(71, 148)
        Me.PlayerDie2.Name = "PlayerDie2"
        Me.PlayerDie2.Size = New System.Drawing.Size(53, 53)
        Me.PlayerDie2.TabIndex = 1
        Me.PlayerDie2.TabStop = False
        '
        'ComputerDie1
        '
        Me.ComputerDie1.Location = New System.Drawing.Point(370, 52)
        Me.ComputerDie1.Name = "ComputerDie1"
        Me.ComputerDie1.Size = New System.Drawing.Size(53, 53)
        Me.ComputerDie1.TabIndex = 2
        Me.ComputerDie1.TabStop = False
        '
        'ComputerDie2
        '
        Me.ComputerDie2.Location = New System.Drawing.Point(370, 148)
        Me.ComputerDie2.Name = "ComputerDie2"
        Me.ComputerDie2.Size = New System.Drawing.Size(53, 53)
        Me.ComputerDie2.TabIndex = 3
        Me.ComputerDie2.TabStop = False
        '
        'lblYou
        '
        Me.lblYou.AutoSize = True
        Me.lblYou.Location = New System.Drawing.Point(98, 13)
        Me.lblYou.Name = "lblYou"
        Me.lblYou.Size = New System.Drawing.Size(26, 13)
        Me.lblYou.TabIndex = 4
        Me.lblYou.Text = "You"
        '
        'lblThem
        '
        Me.lblThem.AutoSize = True
        Me.lblThem.Location = New System.Drawing.Point(389, 13)
        Me.lblThem.Name = "lblThem"
        Me.lblThem.Size = New System.Drawing.Size(34, 13)
        Me.lblThem.TabIndex = 5
        Me.lblThem.Text = "Them"
        '
        'lblVs
        '
        Me.lblVs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblVs.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVs.Location = New System.Drawing.Point(217, 0)
        Me.lblVs.Name = "lblVs"
        Me.lblVs.Size = New System.Drawing.Size(72, 48)
        Me.lblVs.TabIndex = 6
        Me.lblVs.Text = "Vs"
        '
        'lblCurrent
        '
        Me.lblCurrent.AutoSize = True
        Me.lblCurrent.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrent.Location = New System.Drawing.Point(198, 252)
        Me.lblCurrent.Name = "lblCurrent"
        Me.lblCurrent.Size = New System.Drawing.Size(108, 21)
        Me.lblCurrent.TabIndex = 7
        Me.lblCurrent.Text = "Current Game"
        '
        'lblGame
        '
        Me.lblGame.AutoSize = True
        Me.lblGame.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGame.Location = New System.Drawing.Point(227, 297)
        Me.lblGame.Name = "lblGame"
        Me.lblGame.Size = New System.Drawing.Size(49, 21)
        Me.lblGame.TabIndex = 8
        Me.lblGame.Text = "0-0-0"
        '
        'btnNew
        '
        Me.btnNew.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNew.Location = New System.Drawing.Point(392, 250)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(75, 23)
        Me.btnNew.TabIndex = 9
        Me.btnNew.Text = "New Game"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(392, 298)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnRoll
        '
        Me.btnRoll.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoll.Location = New System.Drawing.Point(54, 250)
        Me.btnRoll.Name = "btnRoll"
        Me.btnRoll.Size = New System.Drawing.Size(75, 23)
        Me.btnRoll.TabIndex = 11
        Me.btnRoll.Text = "Roll!"
        Me.btnRoll.UseVisualStyleBackColor = True
        '
        'lblwin1
        '
        Me.lblwin1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwin1.Location = New System.Drawing.Point(228, 90)
        Me.lblwin1.Name = "lblwin1"
        Me.lblwin1.Size = New System.Drawing.Size(45, 15)
        Me.lblwin1.TabIndex = 12
        Me.lblwin1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWin2
        '
        Me.lblWin2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWin2.Location = New System.Drawing.Point(228, 148)
        Me.lblWin2.Name = "lblWin2"
        Me.lblWin2.Size = New System.Drawing.Size(45, 15)
        Me.lblWin2.TabIndex = 13
        Me.lblWin2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picP1
        '
        Me.picP1.Location = New System.Drawing.Point(181, 78)
        Me.picP1.Name = "picP1"
        Me.picP1.Size = New System.Drawing.Size(27, 27)
        Me.picP1.TabIndex = 14
        Me.picP1.TabStop = False
        Me.picP1.Visible = False
        '
        'picC1
        '
        Me.picC1.Location = New System.Drawing.Point(298, 78)
        Me.picC1.Name = "picC1"
        Me.picC1.Size = New System.Drawing.Size(27, 27)
        Me.picC1.TabIndex = 15
        Me.picC1.TabStop = False
        Me.picC1.Visible = False
        '
        'picP2
        '
        Me.picP2.Location = New System.Drawing.Point(181, 148)
        Me.picP2.Name = "picP2"
        Me.picP2.Size = New System.Drawing.Size(27, 27)
        Me.picP2.TabIndex = 16
        Me.picP2.TabStop = False
        Me.picP2.Visible = False
        '
        'PicC2
        '
        Me.PicC2.Location = New System.Drawing.Point(298, 148)
        Me.PicC2.Name = "PicC2"
        Me.PicC2.Size = New System.Drawing.Size(27, 27)
        Me.PicC2.TabIndex = 17
        Me.PicC2.TabStop = False
        Me.PicC2.Visible = False
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.Location = New System.Drawing.Point(228, 211)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(0, 15)
        Me.lblResult.TabIndex = 18
        Me.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ImageList2
        '
        Me.ImageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList2.ImageSize = New System.Drawing.Size(27, 27)
        Me.ImageList2.TransparentColor = System.Drawing.Color.Transparent
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(510, 24)
        Me.MenuStrip1.TabIndex = 19
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(510, 350)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.PicC2)
        Me.Controls.Add(Me.picP2)
        Me.Controls.Add(Me.picC1)
        Me.Controls.Add(Me.picP1)
        Me.Controls.Add(Me.lblWin2)
        Me.Controls.Add(Me.lblwin1)
        Me.Controls.Add(Me.btnRoll)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.lblGame)
        Me.Controls.Add(Me.lblCurrent)
        Me.Controls.Add(Me.lblVs)
        Me.Controls.Add(Me.lblThem)
        Me.Controls.Add(Me.lblYou)
        Me.Controls.Add(Me.ComputerDie2)
        Me.Controls.Add(Me.ComputerDie1)
        Me.Controls.Add(Me.PlayerDie2)
        Me.Controls.Add(Me.PlayerDie1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Space Dice"
        CType(Me.PlayerDie1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PlayerDie2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComputerDie1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComputerDie2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picP1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picC1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picP2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicC2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents PlayerDie1 As System.Windows.Forms.PictureBox
    Friend WithEvents PlayerDie2 As System.Windows.Forms.PictureBox
    Friend WithEvents ComputerDie1 As System.Windows.Forms.PictureBox
    Friend WithEvents ComputerDie2 As System.Windows.Forms.PictureBox
    Friend WithEvents lblYou As System.Windows.Forms.Label
    Friend WithEvents lblThem As System.Windows.Forms.Label
    Friend WithEvents lblVs As System.Windows.Forms.Label
    Friend WithEvents lblCurrent As System.Windows.Forms.Label
    Friend WithEvents lblGame As System.Windows.Forms.Label
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnRoll As System.Windows.Forms.Button
    Friend WithEvents lblwin1 As System.Windows.Forms.Label
    Friend WithEvents lblWin2 As System.Windows.Forms.Label
    Friend WithEvents picP1 As System.Windows.Forms.PictureBox
    Friend WithEvents picC1 As System.Windows.Forms.PictureBox
    Friend WithEvents picP2 As System.Windows.Forms.PictureBox
    Friend WithEvents PicC2 As System.Windows.Forms.PictureBox
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents ImageList2 As System.Windows.Forms.ImageList
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
